package com.cse223.mailserver;

import com.cse223.mailserver.flow.*;
import org.json.simple.parser.ParseException;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

@CrossOrigin
@RestController
//@RequestMapping("/api")
public class Controller {
    Server server = Server.getServer();//Server to get and send data

    @GetMapping("/login")
    public boolean login(@RequestParam("username") String username , @RequestParam("password") String password) throws IOException, ParseException {
        System.out.println("Username is "+ username+"\nPassword is "+password);
        return server.LOGIN(username , password);
    }

    @PostMapping("/signUp")
    @ResponseBody
    public boolean signUp(@RequestBody UserClass user) throws IOException, ParseException {
        System.out.println("Sign up");
        System.out.println(user);
        return server.signUp(user);
    }

    @GetMapping("/getMails")
    public ArrayList<MessageCreator> getMails(@RequestParam(name = "type") String type) throws IOException, ParseException {
        System.out.println(type);
        ArrayList<MessageCreator> mails =server.getMails(type);
        System.out.println(mails);
        return mails;
    }

    @PostMapping("/compose")
    @ResponseBody
    public boolean compose(@RequestParam(name="type")String type,@RequestParam(name = "title")String title , @RequestParam(name = "body") String body
            ,@RequestBody ArrayList<ArrayList<String>> receiversAndFiles ){
        System.out.println("Title is " + title);
        System.out.println("Body is " + body);
        System.out.println(receiversAndFiles);
        ArrayList<String> receivers = receiversAndFiles.get(0);
        ArrayList<String> files = receiversAndFiles.get(1);
        try {
            return type.equals(Constants.Sent) ?  server.createMessage(title, body, "", files, receivers, 0) :
                                                  false;///We put here draft
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }

    @GetMapping("/filter")
    public ArrayList<? extends Message> filterBy(@RequestParam(name = "filterName")String filterName ,
                            @RequestParam(name = "subOrRec") String subOrRec ,
                            @RequestParam(name = "inboxOrSent") String inOrSent){

        System.out.println(filterName);
        System.out.println(subOrRec);
        System.out.println(inOrSent);

        return server.myFilter(filterName, subOrRec, inOrSent);
    }
    @GetMapping("/sort")
    public ArrayList<MessageCreator> getSorted(@RequestParam(name = "folder") String folder , @RequestParam(name="type") String type){
        try {
            System.out.println("Folder is "+folder);
            System.out.println("Type is "+type);
            ArrayList<MessageCreator> mess = server.sort(folder, type);
            System.out.println("Size is  "+ mess.size());
            return mess;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }


    @PostMapping("/file")
    @ResponseBody
    public void save(@RequestBody String[] files) throws IOException {
        for(String i : files){
            System.out.println(i);
        }

    }

    @RequestMapping(value = "/img" , produces = {MediaType.IMAGE_PNG_VALUE , "application/json"})
    public void upload(@RequestParam("imageFile")MultipartFile file , @RequestParam("name") String name) throws IOException {
        Path path = Paths.get(name , ".png");
        Files.write(path , file.getBytes());
        System.out.println("DOne!");
    }
    /**
     * {
     *     body:this.body,
     *
     *
     * }
     */


}

