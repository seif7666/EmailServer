package com.cse223.mailserver.flow;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import com.cse223.mailserver.library.doubleLinkedList;
import org.json.simple.parser.ParseException;




public class Server {
    private UserClass user;
    private User userInterface;
    private ArrayList<User> AllUsers;
    private SaveAndLoad save = new SaveAndLoad();

    /**
     * We instantiated 1 class to be called multiple times.
     */
    private static final Server server = new Server();

    private Server(){}

    public static Server getServer() {
        return server;
    }

    ////////////////login///////////////////////////////////////////////////
    public boolean LOGIN(String Email,String password) throws FileNotFoundException, IOException, ParseException {
        Login loginClass=new Login(Email,password);
        userInterface=loginClass.ExistOrNot();

        if(userInterface==null) {
            return false;
        }else {
            user=new UserClass(userInterface.getUserName(),userInterface.getPassword(),userInterface.getEmail(),userInterface.getBirthday());
            fillCurrentUser(user.getEmail());
            return true;
        }

    }
    public void setAllUsers() throws FileNotFoundException, IOException, ParseException {
        SaveAndLoad saveAndLoad=new SaveAndLoad();
        AllUsers=saveAndLoad.readUsersFromJson();
    }
    /////////////////////////signup///////////////////////////////////////////////
    public boolean signUp(UserClass user) throws IOException, ParseException {
        signUp signUp=new signUp();
        //add Object Of user Here
        this.user = user;
        return signUp.addUser(user);

    }
    ///////////////////////message dealer//////////////////////////////////////////////////////////
    public boolean  createMessage(String subject , String body , String date , ArrayList<String> attaches, ArrayList<String> reciver , int ID) throws IOException, ParseException{
        SaveAndLoad saveAndLoad =new SaveAndLoad();
        MessageHeader header = new MessageHeader(user.getEmail(),reciver,subject);
        MessageBody Body = new MessageBody(body);
        Attachments Attaches = new Attachments(attaches);
        MessageCreator myMessage = new MessageCreator(header,Body,Attaches,date,ID);
        saveAndLoad.sendMessage(myMessage,Constants.Sent,myMessage.getHeader().getSender());
        for(int i=0;i<reciver.size();i++) {
            if(!exist_user(myMessage.getHeader().getReciever().get(i))) {
                return false;
            }
            saveAndLoad.sendMessage(myMessage,Constants.Inbox,myMessage.getHeader().getReciever().get(i));
        }
        user.addsentMessage((Sent)myMessage.buildSentMessage());
        return true;
    }

    private boolean exist_user(String Email) throws FileNotFoundException, IOException, ParseException{
        SaveAndLoad saveAndLoad =new SaveAndLoad();
        ArrayList<User> ExistUser;
        ExistUser=saveAndLoad.readUsersFromJson();
        for(int i=0;i<ExistUser.size();i++){
            if(Email.equals((String) ExistUser.get(i).getEmail())){
                return true;
            }
        }
        return false;
    }



    public ArrayList<MessageCreator> getMails(String type) throws IOException, ParseException {
        return save.readMessages(user.getEmail() , type);
    }

    ////////////////////////////////sort//////////////////////////

    public ArrayList<MessageCreator> sort(String folder,String type) throws FileNotFoundException, IOException, ParseException {
        SaveAndLoad saveAndLoad = new SaveAndLoad();
        ArrayList<MessageCreator> messages = saveAndLoad.readMessages(user.getEmail(), folder);
        System.out.println(type);
        if (type.contentEquals(Constants.DATE)) {
            return messages;
        } else {
            Sort sortMessages = new Sort(type);

            return putMessagesInArrayList(sortMessages.sorting(putMessagesInDoubleLinkedList(messages)));
        }
    }

    public doubleLinkedList putMessagesInDoubleLinkedList(ArrayList<MessageCreator> messages) {
        doubleLinkedList db=new doubleLinkedList();
        for(int i=0;i<messages.size();i++) {
            db.add(messages.get(i));
        }
        return db;

    }

    public ArrayList<MessageCreator> putMessagesInArrayList(doubleLinkedList messages) {
        ArrayList<MessageCreator> arrayListMessages=new ArrayList<MessageCreator>();
        for(int i=0;i<messages.size();i++) {
            arrayListMessages.add((MessageCreator) messages.get(i));
        }
        return arrayListMessages;

    }

    //////////////////////////////////////////////Filter/////////////////////////////////////////////////
    public ArrayList<? extends Message> myFilter (String  filterName , String subjectOrReceiversOrBodyOrDate , String inboxOrSentOrTrashOrDraft ){
        ArrayList<? extends Message> result =new ArrayList<>() ;
        switch (subjectOrReceiversOrBodyOrDate){
            case Constants.SUBJECT:
                Criteria subjectFilter = new SubjectCriteria(filterName);
                result = getMessages(inboxOrSentOrTrashOrDraft, result, subjectFilter);

                break;
            case Constants.RECEIVERS:
                Criteria reciverFilter = new recieversCriteria(filterName);
                result = getMessages(inboxOrSentOrTrashOrDraft, result, reciverFilter);
                break;
            case Constants.BODY:
                Criteria bodyFilter = new BodyCriteria(filterName);
                result = getMessages(inboxOrSentOrTrashOrDraft, result, bodyFilter);
                break;
            case Constants.DATE:
                Criteria dateFilter = new DateCriteria(filterName);
                result = getMessages(inboxOrSentOrTrashOrDraft, result, dateFilter);
                break;
        }

        return result;
    }

    private ArrayList<? extends Message> getMessages(String inboxOrSentOrTrashOrDraft, ArrayList<? extends Message> result, Criteria subjectFilter) {
        switch (inboxOrSentOrTrashOrDraft) {
            case Constants.Inbox:
                result = subjectFilter.filterCriteria(user.getInbox());
                break;
            case Constants.Sent:
                result = subjectFilter.filterCriteria(user.getSentMessage());
                break;
            case Constants.Trash:
                result = subjectFilter.filterCriteria(user.getTrash());
                break;
            case Constants.Draft:
                result = subjectFilter.filterCriteria(user.getDraft());
                break;
        }
        return result;
    }

    public void fillCurrentUser(String Email ) throws FileNotFoundException, IOException, ParseException {
        SaveAndLoad saveAndLoad = new SaveAndLoad();
        ArrayList<MessageCreator> sent= saveAndLoad.readMessages(Email,Constants.Sent);
        ArrayList<MessageCreator> Inbox= saveAndLoad.readMessages(Email,Constants.Inbox);
        if(Inbox==null) {
        }else {
            for(int i=0; i<Inbox.size();i++) {
                user.addInboxMessage((Inbox) Inbox.get(i).buildInboxMessage());
            }
        }
        if(sent==null) {
        }else {
            for(int i=0; i<sent.size();i++) {
                user.addsentMessage((Sent) sent.get(i).buildSentMessage());
            }
        }

    }


}
