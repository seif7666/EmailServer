package com.cse223.mailserver.flow;

public class MessageBody {
	private String body;
	
	

	public MessageBody(String body) {
		super();
		this.body = body;
	}



	public String getBody() {
		return body;
	}
 
}
