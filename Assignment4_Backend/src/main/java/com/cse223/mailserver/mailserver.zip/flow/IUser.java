package com.cse223.mailserver.flow;

import java.util.Date;

/**
 * Read-Only-Interface
 */
public interface IUser {
    public String getEmail();
    public String getBirthday();

}
