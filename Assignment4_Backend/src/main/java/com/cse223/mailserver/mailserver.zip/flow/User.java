package com.cse223.mailserver.flow;

import java.util.Date;

public interface  User {
	
	public String getUserName() ;
	public String getPassword();
	public String getEmail();
	public String  getBirthday();
	
	

}
