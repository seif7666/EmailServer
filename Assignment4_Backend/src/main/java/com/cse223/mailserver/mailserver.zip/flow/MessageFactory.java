package com.cse223.mailserver.flow;

public class MessageFactory {
	public Message getMessage() {
		return null;
	}
}
