package com.cse223.mailserver.flow;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;

import org.json.simple.parser.ParseException;

public class Main {

	public static void main(String[] args) throws IOException, ParseException {
		// TODO Auto-generated method stub
//		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
//
//	    Date date = new Date();
//	    signUp signUp=new signUp();
//		UserClass user=new UserClass("abdoMohame","12333","Mohamed311@gmail.com","2020");
//		//signUp.addUser(user);
//		//signUp.readUsersFromJson();
//		//System.out.println(signUp.addUser(user));
//		ArrayList<String> to=new ArrayList();
//		to.add("mailTO1");
//		ArrayList<String> attaches=new ArrayList();
//		attaches.add("attaches1111");
//
//		 MessageHeader header = new MessageHeader("Mohamed311@gmail.com",to,"subject11");
//	     MessageBody Body = new MessageBody("body1");
//	     Attachments Attaches = new Attachments(attaches);
//	     MessageCreator myMessage = new MessageCreator(header,Body,Attaches,"2020",4);
//	     SaveAndLoad saveAndLoad=new SaveAndLoad();
//	     saveAndLoad.readMessages("Mohamed311@gmail.com","sent");
//
//	}
	}

}
