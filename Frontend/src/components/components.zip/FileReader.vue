<template>
    <label class="text-reader">
        <label>
            Enter path of files separated by end of line:
        </label>
        <label>
            <textarea name="text" v-model = "files" rows="4" cols="50"></textarea>
        </label>
        <input type="submit" value="Submit" @click="loadTextFromFile">

    </label>
</template>

<script>

    export default {
        name : "FileReader",
        data(){
            return{
                files:"",
            };
        },
        methods: {
            loadTextFromFile() {
                console.log(this.files)
                const listOfFiles =this.files.split('\n')
                this.$emit("load" , listOfFiles);
            }
        }
    };
</script>