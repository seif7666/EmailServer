<template>
  <div class="hello">
    <h1>Welcome to Mail Server</h1>
    <router-link to="/signup">
    <button class ="btn1">
      Sign Up
    </button>
    </router-link>
      <router-link to="/login">
        <button class ="btn1">
          Log in
        </button>
      </router-link>

  </div>
</template>
<script lang="ts">
import { Options, Vue } from "vue-class-component";

@Options({
  props: {
    msg: String
  }
})
export default class HelloWorld extends Vue {
  msg!: string;
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style  scoped lang="scss">
.btn1 {
  width: 20%;
  height: 20%;
  padding: 14px 40px;
  border-color: #f1c40f;
  color: #0000ff;
  font-size: 20pt;
  font-family: cursive;
  background-image: -webkit-linear-gradient(45deg, #f1c40f 50%, transparent 50%);
  background-image: linear-gradient(45deg, #f1c40f 50%, transparent 50%);
  background-position: 100%;
  background-size: 400%;
  -webkit-transition: background 300ms ease-in-out;
  transition: background 300ms ease-in-out;
}
.btn1:hover {
  background-position: 0;
}
</style>
