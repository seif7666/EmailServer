<template>
  <div class="A_mail">
    <div   @click = "selectMail">
      <h3 class = "mail-Head">{{ head }}</h3>
      <span class = "email"> {{ email }}</span>
      <span class ="mail-date">{{date}}</span>
      <p class="mail-body">{{ body +" "+id}}</p>
  </div>
    <div>
      <label>
        Select
      </label>
      <input type="checkbox"  v-model = "marked" @click = "checked">
    </div>
  </div>
</template>

<script>

  export default {
    props: ["id","head", "email", "date", "body" , "sent"],
    name: "mail",
    data(){
      return{
        marked:false
      };
    },
    methods:{
      selectMail(){
        const wholeMail={
          head : this.head,
          email : this.email,
          date : this.date,
          body : this.body,
        }
        this.$emit('getTheMail' , wholeMail);
        this.$router.push({name: "singlemail", params: {
          head:this.head,
          email:this.email,
          date:this.date,
          body:this.body,
          isSent:this.sent
        }});

      },
      checked(){
        // console.log("Marker is " + this.marked , this.id);
        this.$emit('getCheckedMail' , this.id , this.marked);

      }
    }
  };

</script>

<style scoped lang="scss">
  .A_mail {
    padding: 15px;
    background: snow;
    box-shadow: 0 0 10px steelblue;
    position: relative;
    text-align: left;
    .mail-date{
      display: block;
      padding: 0 0 5px;
      front-size:14px;
    }
    .email{
      border-radius: 4px;
    }

  }
</style>