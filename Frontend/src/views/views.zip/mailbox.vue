<template>
  <div class="mailbox">
    <div class="multi-button">
      <button>Inbox</button>
      <button>Sent</button>
      <button>Thrash</button>
      <button>Draft</button>
      <button v-on:click="tolog('A')" >logout</button>
    </div>

    <br>
    <br>
    <div class="multi-button">
      <button v-on:click="tocompose()" >compose</button>
      <button>Delete</button>
      <button v-on:click="tocontacts()" >contacts</button>
    </div>
    <br>
    <div class="search">
      <br>
      <label class="textl">Choose   type of filter </label>
      <select id="filter">
        <option value="date">date</option>
        <option value="priority">priority</option>
      </select>
      <br>
      <br>
      <label class="textl">search for    </label>
      <input>
      <br>
      <br>
      <button class="btn">search</button>
    </div>

    <br>
    <div>
      <mail
          v-for="mail in mails"
          v-bind:key="mail.id"
          v-bind:id="mail.id"
          v-bind:head="mail.title"
          v-bind:email="mail.email"
          v-bind:date="mail.date"
          v-bind:body="mail.body"
          v-bind:sent="mail.isSent"
          @getTheMail = "mailSelect"
          @getCheckedMail = "checkMail"
      />
      <p v-for="mail in Mails" v-bind:key="mail.id">
        {{mail.id}}
      </p>
    </div>
  </div>

</template>

<script>
import jsonMails from "@/json/jsonMails.json";
import mail from "@/components/mail";
import {BACKEND_URL , axios} from "../main";

export default {
  data: function () {
    return {
      mails: [],
      selectedMails:[]//List of selected mails by user.
    };
  },
  name: "mailbox",
  components: {mail},
  methods: {
    tolog: function (message) {
      if (message == 'A') {
        this.$router.push('/login')
      }
    },
    mailSelect(mail){
      console.log(mail);
    },
    tocompose: function () {
        this.$router.push('/compose')
    },
    tocontacts: function () {
      this.$router.push('/contacts')
    },
    checkMail(id , marker){
      console.log("In check mail : mailbox.vue");
      console.log(typeof(marker))
      if(marker === false) {
        console.log("TRUE")
        this.selectedMails.push(id)
      }
      else{
        const index = this.selectedMails.indexOf(id);
        if (index > -1) {
          this.selectedMails.splice(index, 1);
        }
      }
      console.table(this.selectedMails)
    }
  },
  async mounted(){
    let sentMails;
    const url = `${BACKEND_URL}getMails?type=sent`;
    await axios.get(url).then(res => sentMails = res.data);
    console.table(sentMails);

    // v-bind:id="mail.id"
    // v-bind:head="mail.title"
    // v-bind:email="mail.email"
    // v-bind:date="mail.date"
    // v-bind:body="mail.body"
    for(let i = 0 ; i<sentMails.length ; i++){
      console.log(sentMails[i]);
      const mail = {
        id : sentMails[i].id,
        title:sentMails[i].header.subject,
        email:sentMails[i].header.reciever,
        body: sentMails[i].body.body,
        isSent:true
      };
      this.mails.push(mail);
    }
    console.table(this.mails);

  }
}

</script>

<style scoped lang="scss">

:root {
  --border-size: 0.125rem;
  --duration: 250ms;
  --ease: cubic-bezier(0.215, 0.61, 0.355, 1);
  --font-family: monospace;
  --color-primary: white;
  --color-secondary: black;
  --color-tertiary: dodgerblue;
  --shadow: rgba(0, 0, 0, 0.1);
  --space: 1rem;
}

* {
  box-sizing: border-box;
}

body {
  height: 100vh;
  margin: 0 auto;
  display: grid;
  place-items: center;
  padding: calc(var(--space) * 2);
  max-width: 700px;
}

.search{
  padding: 15px;
  background: greenyellow;
  box-shadow: 0 0 10px steelblue;
  position: relative;
  text-align: center;
}
.textl{
  font-size: 1.5rem;
}
.btn{
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  padding:
      calc(var(--space) / 1.125)
      var(--space)
      var(--space);
  background: yellow;
  font-size: 16px;
  width:100px;
  height: 40px;
  border-radius: 8px;

}
.btn:hover,
.btn:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background: greenyellow;

}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}


.multi-button {
  display: flex;
  width: 100%;
  box-shadow: var(--shadow) 4px 4px;
}

.multi-button button {
  flex-grow: 1;
  cursor: pointer;
  position: relative;
  padding:
      calc(var(--space) / 1.125)
      var(--space)
      var(--space);
  background: yellow;
  font-size: 1.5rem;
  font-family: var(--font-family);
  text-shadow: var(--shadow) 2px 2px;
  transition: flex-grow var(--duration) var(--ease);
}

.multi-button button + button {
  border-left: var(--border-size) solid black;
  margin-left: calc(var(--border-size) * -1);
}

.multi-button button:hover,
.multi-button button:focus {
  flex-grow: 2;
  color: white;
  outline: none;
  text-shadow: none;
  background: greenyellow;

}

.multi-button button:focus {
  outline: var(--border-size) dashed var(--color-primary);
  outline-offset: calc(var(--border-size) * -3);
}

.multi-button:hover button:focus:not(:hover) {
  flex-grow: 1;
  color: var(--color-secondary);
  background-color: var(--color-primary);
  outline-color: var(--color-tertiary);
}

.multi-button button:active {
  transform: translateY(var(--border-size));
}
</style>