<template>
  <div class="login">
    <h2>Username</h2>
    <input v-model="username" placeholder="Enter username" />
    <h2>Password</h2>
    <input v-model="password" placeholder="Enter password" />
    <br />
    <br />
    <button v-on:click="tomail" class="btn">
      Login
    </button>
    <br />
    <p>Don't have an account</p>
    <button v-on:click="tosign('A')" class="btn">
      Sign Up
    </button>
    <router-view></router-view>
    <br />
  </div>
</template>

<script>
import {BACKEND_URL , axios} from "../main.ts";
export default {
  data(){
    return {
      username: "",
      password: ""
    }
  },
  methods: {
    /**
     * Send to back
     * username, password.
     * Receive confirmation , if received  , switch to mailbox.vue
     */
    tomail:async function() {
      //No need to create a json here, as we have only parameters.
      const url = `${BACKEND_URL}login?username=${this.username}&password=${this.password}`;
      //Now we send data
      let confirmed = false;
      console.log(url);
      await axios.get(url).then(res => {
        console.log(res);
        confirmed = res.data+"";
      });
      //Now we wait for response.
      console.log(confirmed);
      if (confirmed === "true") {
        console.log("Entered here!");
        this.$router.push("/mailbox");
      }
    },
    tosign: function() {
      this.$router.push("/signup");
    }
  }
};
</script>

<style scoped lang="scss">
.btn {
  width: 14%;
  height: 20%;
  padding: 14px 40px;
  border-color: #f1c40f;
  font-size: 20pt;
  background-image: -webkit-linear-gradient(
          45deg,
          #f1c40f 50%,
          transparent 50%
  );
  background-image: linear-gradient(45deg, #f1c40f 50%, transparent 50%);
  background-position: 100%;
  background-size: 400%;
  -webkit-transition: background 300ms ease-in-out;
  transition: background 300ms ease-in-out;
}
.btn:hover {
  background-position: 0;
}
</style>